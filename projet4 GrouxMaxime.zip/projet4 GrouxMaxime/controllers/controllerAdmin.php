<!-- controlleur de la page admin avec appel des classes nécessaires à la page -->
<?php 
include("../config/Database.php");
include("../models/Comment.php");
include("../models/Billet.php");

