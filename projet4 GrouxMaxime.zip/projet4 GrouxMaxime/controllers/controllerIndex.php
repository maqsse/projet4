<!-- Controller de la page index.php avec appels aux différentes classes et au routeur-->
<?php


include("./config/Database.php");
include("./models/Billet.php");
include("./controllers/routeurIndex.php");





 

