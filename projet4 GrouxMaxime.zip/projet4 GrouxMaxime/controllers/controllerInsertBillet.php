<!-- Si on a cliqué sur le bouton envoyer du formulaire "écrire un billet" on crée un tableau pour insérer les données -->
<?php 
if (isset($_POST["submit"]))
    
{
$tab = array(':titre' => strip_tags($_POST['titre']),
':comment' => strip_tags($_POST['comment']),
':auteur' => strip_tags($_POST['auteur']),
':date' => $_POST['date']);



}