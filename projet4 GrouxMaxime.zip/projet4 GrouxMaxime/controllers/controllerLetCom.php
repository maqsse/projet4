<!-- si l'utilisateur poste un commentaire vérification des données et appel fonction letComment -->
<?php
if (isset($_POST["envoyer"]))
{
$tab =
array(
':titre' => htmlspecialchars($_POST['titre']),
':pseudo' => htmlspecialchars($_POST['pseudo']),
':commentaire' => htmlspecialchars($_POST['commentaire']),
':date' => $_POST['date']
);

}
?>