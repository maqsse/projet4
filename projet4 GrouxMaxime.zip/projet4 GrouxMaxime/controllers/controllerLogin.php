<!-- vérif du login pour se connecter au panneau d'administration-->
<?php 
include("../config/Database.php");
if (isset($_POST["submit"]))
	{


	if(isset($_POST['pseudo']) AND $_POST['pseudo'] !== 'Jean' AND isset($_POST['password']) AND $_POST['password'] !== 'projet')
	 {
		
		header("location:../vues/login?error=2.php");
			
	}else
	{
		$_SESSION['pseudo'] = $_POST['pseudo'];
		$_SESSION['password'] = $_POST['password'];
		header("location:../vues/admin.php");


	}


   
}












?>