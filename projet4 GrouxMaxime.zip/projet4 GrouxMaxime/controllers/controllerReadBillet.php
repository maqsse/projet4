<!-- quand on arrive sur la page read_billets.php vérification des paramètres de la page en fonction du titre cliqué et appel au modele et au controlleur -->
<?php 




if ((isset($_GET["titre"])) AND (isset($_GET["id"])))
{

	include("../controllers/routeurCommentbillets.php");
}