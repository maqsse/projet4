<!-- controlleur de la page signal  -->
<?php 

include("../config/Database.php");
include("../models/Comment.php");