 <!-- routeur de la page admin 
Vérification de l'existence des classes, instanciations et appel à la méthode affichSignal pour afficher les signalements -->

<?php 


if (file_exists("../config/Database.php") and file_exists("../models/Comment.php") and file_exists("../models/Billet.php")) 
{
	
	$con= new Database;
	$con->connect();
	$resultats= new Comment;
	$resultats=Comment::affichSignal();
		$ticket= new Billet;

}

// Si on appuie sur le bouton supprimer le commentaire est supprimé (aprés confirmation)

if(isset($_GET["action"]))
{
  $resultats=Comment::deleteComment();
header("location:admin.php");
}

// Si on clique sur le bouton envoyer à la suite de l'écriture d'un billet il est inséré dans la base de données
if (isset($_POST["submit"]))
{


$ticket->insertBillet();
header("location:admin.php");
}			