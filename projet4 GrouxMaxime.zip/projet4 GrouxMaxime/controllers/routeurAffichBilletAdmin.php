<!-- routeur pour l'affichage des billets de la page admin. -->
<?php 
// Affichage des billets
$resultats= Billet::getListe();

//Si on clique sur supprimer le billet est supprimé (aprés confirmation)
if(isset($_GET["action"])=="delete")
{
	
  $resultats=Billet::deleteBillet();
header("location:admin.php");
}

//Si on a cliqué sur mise à jour le billet est mis à jour 
if(isset($_GET["action"])=="maj")
{
  $resultats=Billet::majBillet();
header("location:admin.php");
}
