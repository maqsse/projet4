<!-- routeur qui permet de lire les commentaires des billets en fonction du titre cliqué sur la page readBillets -->
<?php 


$con= new Database;
 $con->connect();
$resultats= new Comment;
$resultats=Comment::getComment();

if (isset($_POST["envoyer"])) 
{


	$com=Comment::letComment();
	header('Location:../index.php');
}

