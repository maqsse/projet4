<!-- Routeur de la page index -->
<?php 

if (file_exists("./config/Database.php") AND file_exists("./models/Billet.php"))
{
  $con= new Database;
 $con->connect();
  $resultats= new Billet;
 $resultats= Billet::getAllBillet();
}

