<!-- routeur de la page login avec connexion à la base de données et vérification des identifiants administrateur-->
<?php

include("../models/Admin.php");
include("../controllers/controllerLogin.php");
$con= new Database;
$con->connect();
$resultats= new Admin;
$resultats->Administration();

if (isset($_GET["error"])==2) {
include("../fonctions.php");
	error();
}