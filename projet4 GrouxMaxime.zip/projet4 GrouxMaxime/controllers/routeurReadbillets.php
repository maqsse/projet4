<!-- routeur de la page readBillets -->
<?php 
include("../config/Database.php");
$con= new Database;
 $con->connect();
include("../models/Billet.php");
$resultats= new Billet;
$resultats= Billet::getBillet();
include("../models/Comment.php");

