<!-- routeur de la page signal  
	On instancie la classe Comment et on met à jour le signalement -->
<?php 

$com= new Comment;
$com->updateSignal();
