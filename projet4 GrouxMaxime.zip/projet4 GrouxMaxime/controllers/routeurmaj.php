 <!-- routeur de la page maj 
Vérification de la présence des fichiers nécessaires et instanciations. -->
<?php 
if (file_exists("../config/Database.php") and file_exists("../models/Comment.php") and file_exists("../models/Billet.php")) 
{
	$con= new Database;
	$con->connect();
	$resultats= new Comment;
	$resultats=Comment::affichSignal();
		$ticket= new Billet;
		$ticket=Billet::getBillet();

}

// Si on a cliqué sur le bouton envoyer aprés modification du billet il est mis à jour
if(isset($_POST["submit"]))
{
  $resultats=Billet::majBillet();

}