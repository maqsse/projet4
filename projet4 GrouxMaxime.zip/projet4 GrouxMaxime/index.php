<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Accueil</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css"
			integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
			<link rel="stylesheet" href="style.css">
			<!-- police d'écriture google fonts -->
			<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
			<link href="https://fonts.googleapis.com/css?family=Sacramento" rel="stylesheet">
			<link href="https://fonts.googleapis.com/css?family=Dancing+Script" rel="stylesheet">
			<link href="https://fonts.googleapis.com/css?family=El+Messiri" rel="stylesheet">
  			<link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
		</head>
		<body>
			<!-- première partie  avec le header contenant le titre du roman  -->
			<div class="container-fluid">
				<header id="header" >
					<a href="./index.php"><p>Jean Forteroche</p>
					<p> son nouveau roman  en ligne</p>
					<p>"Billet simple pour l'Alaska"</p></a>
				</header>
			</div>

			<!-- Petite phrase pour situer l'utilisateur -->
			<script >document.write("<p class='pici'> Vous êtes ici >>" +document.title+ "</p>");</script><br>

			<!-- une section "core" dans laquelle on a le corps de la page avec un petit paragraphe de présentation. On peut y lire les  billets. Quand on clique sur un billet on accède à la page qui le contient avec ses commentaires-->
			<section class="core">
				
				<div class="col-md-8 offset-md-2 ">
					<p>Pour mon nouveau roman, 'Billet simple pour l'Alaska', j'ai décidé d'utiliser une nouvelle forme de publication. Régulièrement, vous retrouverez sur ce blog un nouvel épisode. N'hésitez pas à commenter pour me donner vos impressions, vos idées pour la suite, ce qui vous a plu ou non, j'essaierai d'en tenir compte pour l'épisode suivant!</p>
				</div>
				<!-- affichage des  billets.  -->
				
				<?php
				// Autoloader permettant de charger les différents fichiers nécessaires à la page.
				
				include("fonctions.php");
				function autoload($name)
				{
				if(file_exists($file = './config/' . $name . '.php')){
				require $file;
				
				}
				elseif(file_exists($file1 = './controllers/' . $name . '.php')){
				require $file1;
				}
				elseif(file_exists($file2 = './models/' . $name . '.php')){
				require $file2;
				}
				
				
				}
				spl_autoload_register('autoload');


				
				
				// on inclut le routeur pour afficher les billets
				include("./controllers/routeurIndex.php");
				foreach($resultats as $data=>$contenu)
				{
				?>
				
				<div  id="divindex" class="container-fluid">
					<a href="./vues/readBillets.php?titre=<?php echo ($contenu[1]);?>&id=<?php echo ($contenu[0]);?>">
						<?php  echo "<p>".($contenu[1])."</p>";?></a>
					<?php
					echo "<p id='ptitre'>" .coupeChaine($contenu[2]). "...</p><br>";?>
					<a href="./vues/readBillets.php?titre=<?php echo ($contenu[1]);?>&id=<?php echo ($contenu[0]);?>"
					id="liensuite"	title="Cliquez pour lire la suite">
					(lire la suite) </a>
					<?php echo "<p id='pdate'>publié le " .date("d/m/Y", strtotime($contenu[4])). "</p>";
					?>
					
				</div>
				
				<?php
				echo "<br>";
				}
				?>
				
			</section>
			<section >
				<!-- une dernière partie qui est le pied de page, le footer, dans lequel on a les mentions légales, un copyright et un lien pour se connecter au panneau d'administration -->
				
				<div class="container-fluid">
					<footer>
						<p class="copyright text-muted">Copyright © Jean Forteroche 2016
							<a href="./vues/login.php" title="administration">Administration</a>
							<a href="./vues/mentions.php" title="mentions légales">Mentions légales</a></p>
							
						</footer>
					</div>
					
					
					
				</section>
				<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
			</body>
		</html>