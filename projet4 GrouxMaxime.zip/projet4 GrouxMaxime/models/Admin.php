<!-- Classe qui permet de se connecter à la base de données et de sélectionner le contenu de la table admin -->
<?php
class Admin
{

private static $pseudo;
private static $password;


public static function Administration(){

	$resultats=Database::getBdd()->query('SELECT mdp FROM blog_admin WHERE $_POST["password"]=sha1(projet)');
	return $resultats;
  $resultats->closeCursor ();
}

}