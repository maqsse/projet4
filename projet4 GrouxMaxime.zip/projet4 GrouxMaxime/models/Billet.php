<!-- Classe qui gère la table des billets blog_billet -->
<?php
class Billet
{
private $titre;
private $contenu;
private $auteur;
private $date;
// recupération liste des  derniers billets
static function getListe()
{
$resultats= Database::getBdd()->query("SELECT * FROM blog_billets order by date desc LIMIT 5");
		return $resultats;
		$resultats->closeCursor ();
}
// récupérer l'ensemble des billets
static function getAllBillet()
{
	
	
	$resultats=Database::getBdd()->query("SELECT * FROM blog_billets order by date desc ");
return $resultats;
$resultats->closeCursor ();
}
// récupération d'un billet en particuier en fonction du titre
static function getBillet()
{
	$titre= str_replace("'", "\'", $_GET["titre"]);
	
	$resultats=Database::getBdd()->query("SELECT contenu FROM blog_billets WHERE titre= '$titre' ");
return($resultats);
$resultats->closeCursor ();
}
// insertion des billets
static function insertBillet()
{
$tab = array(':titre' =>  strip_tags($_POST['titre']),
':comment' => strip_tags($_POST['comment']),
':auteur' => strip_tags($_POST['auteur']),
':date' => $_POST['date']
			);
$req = Database::getBdd()->prepare('INSERT INTO blog_billets (titre, contenu, auteur, date) VALUES (:titre, :comment,
:auteur, :date)');
$req->execute($tab);
$req->closeCursor ();
}
// suppression d'un billet
static function deleteBillet()
{
$id= $_GET["id"];
$resultats=Database::getBdd()->query("DELETE FROM blog_billets WHERE id=$id");

}
// mise à jour des billets
static function majBillet()
{
	
	$tab= array(':titre'=>strip_tags($_GET['titre']),':comment'=>strip_tags($_POST['comment']));
	
$resultats=Database::getBdd()->prepare("UPDATE `blog_billets` SET `contenu`= :comment WHERE `titre`= :titre");
$resultats->execute($tab);
$resultats->closeCursor ();
}

}
?>