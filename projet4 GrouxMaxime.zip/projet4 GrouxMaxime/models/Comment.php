<!-- Classe qui gère la table des commentaires blog_comment -->
<?php
class Comment
{
private $titre;
private $pseudo;
private $contenu;
private $date;
private $signalement;
    
// suppression d'un commentaire
static function deleteComment()
{
$id= $_GET["id"];
$resultats=Database::getBdd()->query("DELETE FROM blog_com WHERE id=$id");
$resultats->closeCursor ();
}
// liste des commentaires liés à un billet et bouton signalement
static function getComment()
{
$titre= str_replace("'", "\'", $_GET["titre"]);
$resultats=Database::getBdd()->query("SELECT id,pseudo,contenu,date FROM blog_com WHERE titre= '$titre' order by date desc");


return $resultats;
$resultats->closeCursor ();

}



// affichage des commentaires récemment signalés
static function affichSignal()
{
$resultats=Database::getBdd()->query("SELECT * FROM blog_com WHERE signalement= 1 ");
return $resultats;
$resultats->closeCursor ();
}
// poster un commentaire
static function letComment()
{
$tab =
array(':titre' => htmlspecialchars($_POST['titre']),
':pseudo' => htmlspecialchars($_POST['pseudo']),
':commentaire' => htmlspecialchars($_POST['commentaire']),
':date' => $_POST['date']
);
$req = Database::getBdd()->prepare('INSERT INTO blog_com (titre,pseudo, contenu, date)
VALUES (:titre, :pseudo, :commentaire, :date)');
$req->execute($tab);
$req->closeCursor ();
}
// mise à jour de l'index ( 1 pour signalement )  quand un commentaire est signalé
public function updateSignal()
{
$id= $_GET["id"];
$resultats=Database::getBdd()->query("UPDATE `blog_com` SET `signalement`=1 WHERE `id`=$id ");
$resultats->closeCursor ();
}


}
?>