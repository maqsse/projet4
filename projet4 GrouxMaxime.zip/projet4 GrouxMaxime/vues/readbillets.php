<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>lecture du billet</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <link rel="stylesheet" href="../style.css">
    <!-- police d'écriture google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Sacramento" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Dancing+Script" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=El+Messiri" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
 </head>
  <body>
    <!-- première partie  avec le header contenant  le titre du roman et 1 phrase de présentation. -->
    <header id="header" class="col-md-12">
      <a href="../index.php" title="Accueil"><p>Jean Forteroche</p>
      <p> son nouveau roman  en ligne</p>
      <p>"Billet simple pour l'Alaska"</p></a>
    </header>
    <!-- Petite phrase pour situer l'utilisateur -->
    <script >document.write("<p class='pici'> Vous êtes ici >>" +document.title+ "</p>");</script><br>
    <!-- La section core qui est constituée du contenu principal de la page -->
    <section class="core " >
      
      <!-- lecture du billet selectionné  avec ses commentaires et bouton pour pouvoir signaler un commentaire-->
      
      <div class="container-fluid" id="divbillets">
        <!-- On affiche le titre du billet -->
        <?php
        ob_start();
        echo "<p id='pundivbillets'>  titre du billet: " .$_GET["titre"]. " écrit par Jean Forteroche</p>";
        // on récupère le billet par l'appel au routeur
        include("../controllers/routeurReadbillets.php");
        foreach($resultats as $data=>$contenu)
        {        
        echo "<p>" .($contenu[0]). "</p>";
        echo "<br>";
        }
        ?>
        
        <div class="divvide">
          
        </div>
        <h5>Commentaire(s):</h5><br>
        <?php
        
        // on récupère la liste des commentaires
        include("../controllers/routeurCommentbillets.php");
        //mise à jour des signalements
        include("../controllers/routeurSignal.php");
        foreach($resultats as $data=>$contenu)
        {
        ?>
      </div>
      <div class="container-fluid" id="divcom">
        
        <?php
        echo "<p >" .($contenu[1]). " >> "  .($contenu[2]). " le " .date("d/m/Y", strtotime($contenu[3])). "</p>";?>
        
        <p id="pcomappropri">Ce commentaire ne vous semble pas approprié? Vous pouvez le signaler à l'administrateur en cliquant sur ce bouton: </p>
        <button class="btn btn-primary btn-sm active" role="button" aria-pressed="true"
        id="signalbutton"><a href="readbillets.php?action=1&id=<?php echo($contenu[0]);?>&titre=<?php echo($_GET['titre']);?>"  id="signalbutton" title="Cliquez pour signaler ce commentaire" class="btn btn-primary btn-sm active" role="button" aria-pressed="true" onclick="if(!confirm('Etes-vous sûr de signaler ce commentaire?')) return false;">Signaler</a></button><br>
      </div>
      <?php
      }
      ob_end_flush();
      ?>
      
      <!-- petit formulaire pour poster un commentaire -->
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-7 offset-md-5" id="divbutton">
            <button id="poster_com"> Poster un commentaire </button>
          </div>
        </div>
      </div>
      
      <div class="container-fluid" >
        <p>Pour envoyer un commentaire au sujet du billet il vous suffit de remplir les champs de ce petit formulaire. Par la suite vous serez redirigé automatiquement à la page d'accueil du site.</p>
        <form action="#" method="post" accept-charset="utf-8" id="formcom">
          <div class="form-group row">
            
            <div class="col-sm-8 offset-sm-2">
              <input type="text" name="titre" class="form-control" id="titre" readonly="readonly" value="<?php echo $_GET["titre"]?>">
            </div>
          </div>
          <div class="form-group row">
            
            <div class="col-sm-8 offset-sm-2">
              <input type="text" name="pseudo" class="form-control" id="pseudo" placeholder="votre pseudo" required="required">
            </div>
          </div>
          <div class="form-group row">
            
            <div class="col-sm-8 offset-sm-2">
              <textarea name="commentaire" class="form-control" id="exampleFormControlTextarea1" rows="5" placeholder="votre commentaire"
              required="required"></textarea>
            </div>
          </div>
          <div class="form-group row">
            
            <div class="col-sm-8 offset-sm-2">
              <input type="date" name="date" class="form-control" id="date" required="required">
              
              <button type="submit" name="envoyer" class="btn btn-primary"  id="submit" title="Envoyer">Envoyer</button>
            </div>
          </div>
        </form>
        <a href="../index.php" title="">Retour à l'accueil</a>
      </div>
    </section>
    <section >
      <!-- une dernière partie qui est le pied de page, le footer, dans lequel on a les mentions légales, un copyright et une icone pour se connecter au panneau d'administration -->
      <footer>
        
        <p class="copyright text-muted">Copyright © Jean Forteroche 2016
          <a href="login.php" title="administration">Administration</a>
          <a href="mentions.php" title="mentions légales">Mentions légales</a></p>
          
          
          
        </footer>
        
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
      </section>
    </body>
  </html>